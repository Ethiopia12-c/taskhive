import type { Request, Response } from "express"
import Job from "../models/Job"

export const postJob = async (req: Request, res: Response) => {
  try {
    const { title, description, skills, budgetMin, budgetMax, promote } = req.body
    const clientId = (req as any).userId

    const newJob = new Job({
      title,
      description,
      skills,
      budgetMin,
      budgetMax,
      promote,
      client: clientId,
    })

    await newJob.save()

    res.status(201).json(newJob)
  } catch (error) {
    res.status(500).json({ message: "Server error" })
  }
}

export const getJobs = async (req: Request, res: Response) => {
  try {
    const jobs = await Job.find().populate("client", "name email")

    res.json(jobs)
  } catch (error) {
    res.status(500).json({ message: "Server error" })
  }
}

