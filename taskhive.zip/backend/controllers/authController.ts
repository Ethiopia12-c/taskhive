import type { Request, Response } from "express"
import bcrypt from "bcryptjs"
import jwt from "jsonwebtoken"
import User from "../models/User"

const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key"

export const register = async (req: Request, res: Response) => {
  try {
    const { email, password, role } = req.body

    // Check if user already exists
    const existingUser = await User.findOne({ email })
    if (existingUser) {
      return res.status(400).json({ message: "User already exists" })
    }

    // Hash password
    const salt = await bcrypt.genSalt(10)
    const hashedPassword = await bcrypt.hash(password, salt)

    // Create new user
    const newUser = new User({
      email,
      password: hashedPassword,
      role,
    })

    await newUser.save()

    // Create and send JWT token
    const token = jwt.sign({ userId: newUser._id }, JWT_SECRET, { expiresIn: "1d" })

    res.status(201).json({ token })
  } catch (error) {
    res.status(500).json({ message: "Server error" })
  }
}

export const login = async (req: Request, res: Response) => {
  try {
    const { email, password } = req.body

    // Check if user exists
    const user = await User.findOne({ email })
    if (!user) {
      return res.status(400).json({ message: "Invalid credentials" })
    }

    // Check password
    const isMatch = await bcrypt.compare(password, user.password)
    if (!isMatch) {
      return res.status(400).json({ message: "Invalid credentials" })
    }

    // Create and send JWT token
    const token = jwt.sign({ userId: user._id }, JWT_SECRET, { expiresIn: "1d" })

    res.json({ token })
  } catch (error) {
    res.status(500).json({ message: "Server error" })
  }
}

5
Freelancer
Profile
API

```typescript file="backend/controllers/freelancerController.ts"
import { Request, Response } from 'express'
import User from '../models/User'

export const updateProfile = async (req: Request, res: Response) => {
  try {
    const { name, bio, skills, paymentPreference } = req.body
    const userId = (req as any).userId // Assuming you have middleware to extract userId from token

    const updatedUser = await User.findByIdAndUpdate(
      userId,
      { 
        name, 
        bio, 
        skills, 
        paymentPreference,
        profileCompleted: true
      },
      { new: true }
    )

    if (!updatedUser) {
      return res.status(404).json({ message: 'User not found' })
    }

    res.json(updatedUser)
  } catch (error) {
    res.status(500).json({ message: 'Server error' })
  }
}

export const getProfile = async (req: Request, res: Response) => {
  try {
    const userId = (req as any).userId

    const user = await User.findById(userId).select('-password')

    if (!user) {
      return res.status(404).json({ message: 'User not found' })
    }

    res.json(user)
  } catch (error) {
    res.status(500).json({ message: 'Server error' })
  }
}

