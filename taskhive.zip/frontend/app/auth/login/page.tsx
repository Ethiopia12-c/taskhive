"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { FaGoogle, FaTelegram } from "react-icons/fa"

export default function Login() {
  const [formData, setFormData] = useState({
    email: "",
    password: "",
  })
  const router = useRouter()

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value })
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    // Submit the form data to the backend
    const response = await fetch("/api/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(formData),
    })

    if (response.ok) {
      router.push("/dashboard")
    } else {
      // Handle error
      console.error("Login failed")
    }
  }

  const handleSocialLogin = (provider: string) => {
    // Implement social login logic
    console.log(`Login with ${provider}`)
  }

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-100">
      <div className="w-full max-w-md p-8 space-y-4 bg-white rounded-lg shadow-md">
        <h1 className="text-2xl font-bold text-center">Login to TaskHive</h1>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="email">Email</Label>
            <Input id="email" name="email" type="email" required value={formData.email} onChange={handleInputChange} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="password">Password</Label>
            <Input
              id="password"
              name="password"
              type="password"
              required
              value={formData.password}
              onChange={handleInputChange}
            />
          </div>
          <Button type="submit" className="w-full">
            Login
          </Button>
        </form>
        <div className="flex flex-col space-y-2">
          <Button onClick={() => handleSocialLogin("google")} variant="outline" className="w-full">
            <FaGoogle className="mr-2" /> Login with Google
          </Button>
          <Button onClick={() => handleSocialLogin("telegram")} variant="outline" className="w-full">
            <FaTelegram className="mr-2" /> Login with Telegram
          </Button>
        </div>
      </div>
    </div>
  )
}

