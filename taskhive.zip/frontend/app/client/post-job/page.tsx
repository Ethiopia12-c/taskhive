"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Checkbox } from "@/components/ui/checkbox"

export default function PostJob() {
  const [jobPost, setJobPost] = useState({
    title: "",
    description: "",
    skills: [],
    budgetMin: "",
    budgetMax: "",
    promote: false,
  })

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setJobPost({ ...jobPost, [e.target.name]: e.target.value })
  }

  const handleSkillChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const skills = e.target.value.split(",").map((skill) => skill.trim())
    setJobPost({ ...jobPost, skills })
  }

  const handlePromoteChange = (checked: boolean) => {
    setJobPost({ ...jobPost, promote: checked })
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    // Submit the job post data to the backend
    const response = await fetch("/api/client/post-job", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(jobPost),
    })

    if (response.ok) {
      // Handle success
      console.log("Job posted successfully")
    } else {
      // Handle error
      console.error("Job posting failed")
    }
  }

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-2xl font-bold mb-4">Post a New Job</h1>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="title">Job Title</Label>
          <Input id="title" name="title" value={jobPost.title} onChange={handleInputChange} required />
        </div>
        <div className="space-y-2">
          <Label htmlFor="description">Job Description</Label>
          <Textarea
            id="description"
            name="description"
            value={jobPost.description}
            onChange={handleInputChange}
            required
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="skills">Required Skills (comma-separated)</Label>
          <Input id="skills" name="skills" value={jobPost.skills.join(", ")} onChange={handleSkillChange} required />
        </div>
        <div className="flex space-x-4">
          <div className="space-y-2 flex-1">
            <Label htmlFor="budgetMin">Minimum Budget</Label>
            <Input
              id="budgetMin"
              name="budgetMin"
              type="number"
              value={jobPost.budgetMin}
              onChange={handleInputChange}
              required
            />
          </div>
          <div className="space-y-2 flex-1">
            <Label htmlFor="budgetMax">Maximum Budget</Label>
            <Input
              id="budgetMax"
              name="budgetMax"
              type="number"
              value={jobPost.budgetMax}
              onChange={handleInputChange}
              required
            />
          </div>
        </div>
        <div className="flex items-center space-x-2">
          <Checkbox id="promote" checked={jobPost.promote} onCheckedChange={handlePromoteChange} />
          <Label htmlFor="promote">Promote this job post (additional fee applies)</Label>
        </div>
        <Button type="submit">Post Job</Button>
      </form>
    </div>
  )
}

