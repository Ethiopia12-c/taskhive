"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function FreelancerProfile() {
  const [profile, setProfile] = useState({
    name: "",
    bio: "",
    skills: [],
    paymentPreference: "",
  })

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setProfile({ ...profile, [e.target.name]: e.target.value })
  }

  const handleSkillChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const skills = e.target.value.split(",").map((skill) => skill.trim())
    setProfile({ ...profile, skills })
  }

  const handlePaymentPreferenceChange = (value: string) => {
    setProfile({ ...profile, paymentPreference: value })
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    // Submit the profile data to the backend
    const response = await fetch("/api/freelancer/profile", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(profile),
    })

    if (response.ok) {
      // Handle success
      console.log("Profile updated successfully")
    } else {
      // Handle error
      console.error("Profile update failed")
    }
  }

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-2xl font-bold mb-4">Freelancer Profile</h1>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="name">Name</Label>
          <Input id="name" name="name" value={profile.name} onChange={handleInputChange} required />
        </div>
        <div className="space-y-2">
          <Label htmlFor="bio">Bio</Label>
          <Textarea id="bio" name="bio" value={profile.bio} onChange={handleInputChange} required />
        </div>
        <div className="space-y-2">
          <Label htmlFor="skills">Skills (comma-separated)</Label>
          <Input id="skills" name="skills" value={profile.skills.join(", ")} onChange={handleSkillChange} required />
        </div>
        <div className="space-y-2">
          <Label htmlFor="paymentPreference">Payment Preference</Label>
          <Select onValueChange={handlePaymentPreferenceChange} value={profile.paymentPreference}>
            <SelectTrigger>
              <SelectValue placeholder="Select payment preference" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="paypal">PayPal</SelectItem>
              <SelectItem value="bankTransfer">Bank Transfer</SelectItem>
              <SelectItem value="crypto">Cryptocurrency</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <Button type="submit">Update Profile</Button>
      </form>
    </div>
  )
}

