"use client"

import app from "../backend/app"

export default function SyntheticV0PageForDeployment() {
  return <app />
}